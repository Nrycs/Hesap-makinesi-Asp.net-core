﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controlers
{
    public class HomeController : Controller
    {
        private DataContext context;
        public HomeController(DataContext _context)
        {
            context = _context;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View(context.hesapMakinesis);
        }
        [HttpPost]
        public IActionResult Index(int _ilkSayi, int _ikincisayi, int _cevap, Islemenum _islem)
        {

            //context.hesapMakinesis.Add(Cevap);
            //context.SaveChanges();
            return View(context.hesapMakinesis);

        }

        [HttpPost]
        public IActionResult IslemKaydet(int _ilkSayi, int _ikincisayi, string _cevap, Islemenum _islem)
        {
            HesapMakinesi hesapMak = new HesapMakinesi();
            hesapMak.Sayı1 = _ilkSayi.ToString();
            hesapMak.Sayı2 = _ikincisayi.ToString();
            hesapMak.cevap = _cevap;
            hesapMak.islemler = _islem;

            context.hesapMakinesis.Add(hesapMak);
            int sonuc = context.SaveChanges();
            if (sonuc > 0)
            {
                return Json(new { result = 1 });
            }
            else
            {
                return Json(new { result = 0 });
            }

        }

        [HttpPost]
        public IActionResult Delete()
        {
            context.hesapMakinesis.RemoveRange(context.hesapMakinesis.ToList());
            context.SaveChanges();
            return View();
        }



        [HttpGet]
        public IActionResult list()
        {
            return View(context.hesapMakinesis);
        }

        [HttpPost]
        public IActionResult list(int id)
        {
            return View(context.hesapMakinesis);
        }

        [HttpGet]
        public IActionResult Deleted(int id)
        {
            HesapMakinesi silinecek = context.hesapMakinesis.Find(id);

            if (silinecek != null)
            {
                context.hesapMakinesis.Remove(silinecek);
                int save = context.SaveChanges();
                if (save > 0)
                {
                    TempData["response"] = "Silme islemi basarili.";
                }
                else
                {
                    TempData["response"] = "Silme islemi basarisiz !";
                }
            }
            else
            {
                TempData["response"] = "Verinin id bilgisi bulunamadi !";
            }

            return RedirectToAction("list", "home");
        }


        [HttpGet]
        public IActionResult Edit(int Id)
        {

           HesapMakinesi item = context.hesapMakinesis.FirstOrDefault(x => x.Id == Id);
                
            
            return View(item);
        }

        [HttpPost]
        public IActionResult Edit(int _Id, int _sayi1, int _sayi2, string _cevap, Islemenum _islem)
        {
            HesapMakinesi edit = context.hesapMakinesis.Find(_Id);
            if (edit != null)
            {

                HesapMakinesi Old = context.hesapMakinesis.Find(_Id);
                HesapMakinesi guncelle = Old;

                guncelle.Sayı1 = _sayi1.ToString();
                guncelle.Sayı2 = _sayi2.ToString();
                guncelle.cevap = _cevap;
                guncelle.islemler = _islem;
                context.Entry(Old).CurrentValues.SetValues(guncelle);


                int save = context.SaveChanges();
                if (save > 0)
                {
                    TempData["Response"] = "Günceleme  islemi basarili.";
                }
                else
                {
                    TempData["Response"] = "Günceleme islemi basarisiz !";
                }
            }
            else
            {
                TempData["Response"] = "Verinin id bilgisi bulunamadi !";
            }
            return RedirectToAction("list", "home");
        }






    }
}
