﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication2.Migrations
{
    public partial class creaatnewmigrationula : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Sayı1",
                table: "hesapMakinesis",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Sayı2",
                table: "hesapMakinesis",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Sayı1",
                table: "hesapMakinesis");

            migrationBuilder.DropColumn(
                name: "Sayı2",
                table: "hesapMakinesis");
        }
    }
}
