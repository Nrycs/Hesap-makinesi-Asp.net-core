﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class HesapMakinesi
    {

        public int Id { get; set; }

        public string Sayı1 { get; set; }
        public string Sayı2 { get; set; }
        public string cevap { get; set; }
        public Islemenum islemler { get; set; }

    }
}
