﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public enum Islemenum
    {
        toplam=1,
        Cıkarma=2,
        Carpma=3,
        Bolme=4
       

    }
}
